
export interface Character{
    name:string,
    healthy:number
}